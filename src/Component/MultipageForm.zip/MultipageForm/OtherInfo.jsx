import React from 'react'

function OtherInfo({formdata,setformdata}) {
  const handlechange=(e)=>{
    let {name,value}=e.target
    setformdata({...formdata,[name]:value})

  }
  return (
    <div className='m-5'>
        <div>
      <label>Nationality</label><br/>
      <input type='text' value={formdata.nationality} onChange={handlechange} name='nationality' placeholder='Enter Your Nationality'></input>
      </div>
      <div>
      <label>Father'Name</label><br/>
      <input type='text' value={formdata.fathername} onChange={handlechange} name='fathername' placeholder='Enter Fathers Name'></input>
      </div>
      </div>
  )
}

export default OtherInfo
