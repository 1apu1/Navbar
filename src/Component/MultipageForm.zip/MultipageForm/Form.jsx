import React, { useState } from "react";
import SignUpInfo from "./SignUpInfo";
import PersonalInfo from "./PersonalInfo";
import OtherInfo from "./OtherInfo";

function Form() {
  const [page, setPage] = useState(0);
  let arr = ["SignUpInfo", "PersonalInfo", "Other"];
  const [formdata, setformdata] = useState({
    gmail: "",
    password: "",
    confirmpassword: "",
    firstname: "",
    lastname: "",
    dob: "",
    nationality: "",
    fathername: "",
  });
  function PageDisplay() {
    if (page === 0) {
      return <SignUpInfo formdata={formdata} setformdata={setformdata} />;
    } else if (page === 1) {
      return <PersonalInfo formdata={formdata} setformdata={setformdata} />;
    } else if (page == 2) {
      return <OtherInfo formdata={formdata} setformdata={setformdata} />;
    }
  }
  return (
    <>
      <div class="containerr m-auto w-50 shadow">
        <div class="header text-center">
          <h1>{arr[page]}</h1>
        </div>
        <div className="form-body">{PageDisplay()}</div>

        <div className="form-footer text-center">
          <button
            className="btn btn-sm btn-outline-waring "
            disabled={page == 0}
            onClick={() => {
              setPage((prev) => prev - 1);
            }}
          >
            Pre
          </button>

          <button
            className=" btn btn-sm btn-outline-success"
            onClick={() => {
              if (page === 2) {
                alert("form is submitted");
                console.log(formdata);
              } else {
                setPage((prev) => prev + 1);
              }
            }}
          >
            {page === arr.length - 1 ? "submit" : "next"}
          </button>
        </div>
      </div>
    </>
  );
}

export default Form;
