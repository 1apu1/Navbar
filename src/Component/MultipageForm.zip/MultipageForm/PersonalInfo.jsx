import React from 'react'

function PersonalInfo({formdata,setformdata}) {
  const handlechange=(e)=>{
    let {name,value}=e.target
    setformdata({...formdata,[name]:value})

  }
  return (
    <div className='m-5'>
        <div >
        <label>FirstName</label><br/>
        <input type='text' value={formdata.firstname}  onChange={handlechange} name='firstname' placeholder='Enter the Firstname'></input>
        </div>
        <div>
        <label>LastName</label><br/>
        <input type='text' value={formdata.lastname} onChange={handlechange} name='lastname' placeholder='Enter the Lastname'></input>
        </div>
        <div>
        <label>Dob</label><br/>
        <input type='date' value={formdata.dob} onChange={handlechange} name='dob' placeholder='Enter the Dob'></input>
        </div>
        
      
    </div>
  )
}

export default PersonalInfo
